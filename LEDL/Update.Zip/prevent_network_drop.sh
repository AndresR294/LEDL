#!/usr/bin/env bash
BASE="/data/data/com.termux/files/home/LEDL"
LOG="$BASE/state/network_audit.log"
think() { echo "[🛡️ AIKO $(date +"%H:%M:%S")] $1" | tee -a "$LOG"; }
smoke_test_connectors() {
    local gate_ping=$(ping -c 1 8.8.8.8 | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')
    [ "$gate_ping" -eq 1 ] && think "✅ Red Estable" || think "⚠️ Re-sincronizando..."
}
while true; do smoke_test_connectors; sleep 300; done
