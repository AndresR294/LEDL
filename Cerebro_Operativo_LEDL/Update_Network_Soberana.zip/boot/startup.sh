#!/bin/bash
echo -e "\033[1;32m[SISTEMA OPERATIVO LEDL]: INICIANDO DESDE USB...\033[0m"
# Ruta relativa al punto de montaje
BASE_PATH="."
if [ -f "$BASE_PATH/update_pkg/core/network/mapeo_soberano_v6.sh" ]; then
    bash "$BASE_PATH/update_pkg/core/network/mapeo_soberano_v6.sh"
else
    echo -e "\033[1;31m[ERROR]: No se encontró el motor de red en $BASE_PATH\033[0m"
    exit 1
fi
